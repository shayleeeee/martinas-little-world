# Martina's Little World 💖

A free, mobile-friendly romantic boredom-buster website made with plain HTML, CSS and JavaScript.

## Publish it free with GitHub Pages

1. Go to https://github.com/ and create a free account or sign in.
2. Click the **+** in the top-right, then **New repository**.
3. Name the repository `martinas-little-world`.
4. Set it to **Public**, tick **Add a README file** if offered, then create it.
5. Open the repository and click **Add file → Upload files**.
6. Upload `index.html` from this folder. If you downloaded the ZIP, unzip it first.
7. Click **Commit changes**.
8. In the repository, open **Settings → Pages**.
9. Under **Build and deployment**, choose **Deploy from a branch**.
10. Choose branch **main** and folder **/(root)**, then click **Save**.
11. Wait a minute or two and refresh that Pages screen. GitHub will show your website link, usually:
   `https://YOUR-USERNAME.github.io/martinas-little-world/`
12. Open the link on your phone to test it, then send it to Martina.

## Personalise it

Open `index.html` in a text editor. Search for `const notes =` to replace the sample secret notes with your own. You can also change the greeting and other text by searching for the words in the file. Upload the edited file again to GitHub and commit the changes.

## Important privacy note

This is a static website, so it has no private login or server-side database. Anyone with the link can view it. Notes, memories and wishes entered into the website are stored in local browser storage on the device where they were entered; they do **not** automatically sync between your laptop and Martina's phone. Do not enter passwords or sensitive information. For a truly private website, you would need to add a secure login/backend or use a private platform.

## Troubleshooting

- If you see a 404 page, make sure the file is named exactly `index.html`, it is in the repository root, and Pages is enabled on the `main` branch with `/(root)`.
- If changes don't appear, wait a minute and refresh the page.
- GitHub Pages hosting is free for public repositories. You do not need to buy a custom domain.
